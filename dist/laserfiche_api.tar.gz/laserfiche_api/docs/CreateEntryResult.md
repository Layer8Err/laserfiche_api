# CreateEntryResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operations** | [**CreateEntryOperations**](CreateEntryOperations.md) |  | [optional] 
**document_link** | **str** | A link to get the created entry. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

