# FieldToUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**values** | [**list[ValueToUpdate]**](ValueToUpdate.md) | The field values that will be assigned to the field. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

