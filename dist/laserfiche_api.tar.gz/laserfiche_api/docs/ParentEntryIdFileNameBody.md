# ParentEntryIdFileNameBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**electronic_document** | **str** | The electronic document that will be uploaded. | [optional] 
**request** | [**PostEntryWithEdocMetadataRequest**](PostEntryWithEdocMetadataRequest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

