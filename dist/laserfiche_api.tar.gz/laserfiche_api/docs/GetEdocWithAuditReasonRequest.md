# GetEdocWithAuditReasonRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audit_reason_id** | **int** | The reason id for this audit event. | [optional] 
**comment** | **str** | The comment for this audit event. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

