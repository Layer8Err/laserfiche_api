# TemplateFieldInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule** | [**Object**](Object.md) | A form logic rule associated with a Laserfiche template and field definition. | [optional] 
**group_id** | **int** | The group id of the field in the template. | [optional] 
**group_name** | **str** | The name of field group. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

