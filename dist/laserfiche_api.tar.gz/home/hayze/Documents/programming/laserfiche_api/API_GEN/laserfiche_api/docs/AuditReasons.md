# AuditReasons

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delete_entry** | [**list[WAuditReason]**](WAuditReason.md) | The audit reasons associated with delete entry. | [optional] 
**export_document** | [**list[WAuditReason]**](WAuditReason.md) | The audit reasons associated with export document. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

