# GetDynamicFieldLogicValueRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template_id** | **int** | The template id. | [optional] 
**field_values** | **dict(str, str)** | The dynamic fields. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

