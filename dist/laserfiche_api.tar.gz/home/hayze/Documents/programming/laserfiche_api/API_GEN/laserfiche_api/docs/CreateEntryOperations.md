# CreateEntryOperations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entry_create** | [**EntryCreate**](EntryCreate.md) |  | [optional] 
**set_edoc** | [**SetEdoc**](SetEdoc.md) |  | [optional] 
**set_template** | [**SetTemplate**](SetTemplate.md) |  | [optional] 
**set_fields** | [**SetFields**](SetFields.md) |  | [optional] 
**set_tags** | [**SetTags**](SetTags.md) |  | [optional] 
**set_links** | [**SetLinks**](SetLinks.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

