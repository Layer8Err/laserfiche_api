# Shortcut

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target_id** | **int** | The entry ID of the shortcut target. | [optional] 
**extension** | **str** | The extension of the shortcut target. | [optional] 
**target_type** | [**Object**](Object.md) | The entry type of the shortcut target. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

