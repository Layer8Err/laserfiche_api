# PutTemplateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template_name** | **str** | The template that will be assigned to the entry. | [optional] 
**fields** | [**dict(str, FieldToUpdate)**](FieldToUpdate.md) | The template fields that will be assigned to the entry. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

