# ValueToUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | The value assigned to the field at the position specified. | [optional] 
**position** | **int** | The position of the value in the field. This is 1-indexed. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

