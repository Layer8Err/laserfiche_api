# SessionKeyInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auth_token** | **str** | The auth token that can be used to authenticate with the repository apis. | [optional] 
**expire_time** | **datetime** | The auth token expire time. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

