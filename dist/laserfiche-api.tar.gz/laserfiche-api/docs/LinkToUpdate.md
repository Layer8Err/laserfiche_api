# LinkToUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link_type_id** | **int** | The id of the link assigned to the entry. | [optional] 
**other_source_id** | **int** | The id of the other source linked to the entry. | [optional] 
**is_source** | **bool** | Whether the entry is the source for the link. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

